package online.hualin.flymsg.event;

public class MsgArriveEvent  {
}
