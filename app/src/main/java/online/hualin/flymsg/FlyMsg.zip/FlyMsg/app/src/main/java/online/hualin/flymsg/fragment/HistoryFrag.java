package online.hualin.flymsg.fragment;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.speedystone.greendaodemo.db.ChatHistoryDao;
import com.speedystone.greendaodemo.db.DaoSession;

import java.util.ArrayList;
import java.util.List;

import online.hualin.flymsg.App;
import online.hualin.flymsg.R;
import online.hualin.flymsg.activity.Activity;
import online.hualin.flymsg.adapter.ChatHisAdapter;
import online.hualin.flymsg.db.ChatHistory;

import static online.hualin.flymsg.App.getApplication;
import static online.hualin.flymsg.utils.CommonUtils.closeInputBoard;

public class HistoryFrag extends Fragment {
    private RecyclerView recyclerView;
    private Activity activity;
    private View view;
    private ChatHisAdapter adapter;
    private List<ChatHistory> chatHistories = new ArrayList<>();
    private Context context;
    private SwipeRefreshLayout swipeRefreshLayout;
    private SearchView searchView;
    private ListView listView;

    @Override
    public void onStart() {
        super.onStart();
        DaoSession daoSession = ((App) getApplication()).getDaoSession();
        ChatHistoryDao chatHistoryDao = daoSession.getChatHistoryDao();

        chatHistories = chatHistoryDao.loadAll();
//        List<String> listString = new ArrayList<>();
//        for (ChatHistory chatHistory : chatHistories) {
//            listString.add(chatHistory.getSendMsg());
//        }
//        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_dropdown_item_1line,listString);
//        listView.setAdapter(arrayAdapter);
        adapter = new ChatHisAdapter(chatHistories);
        recyclerView.setAdapter(adapter);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.main_frag, container, false);
        recyclerView = view.findViewById(R.id.recycle_view);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(linearLayoutManager);
        swipeRefreshLayout = view.findViewById(R.id.swipe_refresh);
//        searchView = view.findViewById(R.id.search_view);
//        listView = view.findViewById(R.id.search_list);
////
//        listView.setTextFilterEnabled(true);
//
//        searchView.setSubmitButtonEnabled(true);
//        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
//            @Override
//            public boolean onQueryTextSubmit(String query) {
//                closeInputBoard(getActivity());
//                return false;
//            }
//
//            @Override
//            public boolean onQueryTextChange(String newText) {
//                if (TextUtils.isEmpty(newText)) {
//                    listView.setVisibility(View.GONE);
//                    listView.clearTextFilter();
//
//                } else {
//                    listView.setVisibility(View.VISIBLE);
//                    listView.setFilterText(newText);
//                    return false;
//                }
//                return true;
//            }
//
//        });

        swipeRefreshLayout.setColorSchemeResources(R.color.colorPrimary);
        swipeRefreshLayout.setOnRefreshListener(() -> {
                    this.onStart();
                    swipeRefreshLayout.setRefreshing(false);
                }
        );
        return view;
    }
}
