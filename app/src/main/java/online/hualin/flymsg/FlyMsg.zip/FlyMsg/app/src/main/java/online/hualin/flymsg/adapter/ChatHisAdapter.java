package online.hualin.flymsg.adapter;

import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import online.hualin.flymsg.R;
import online.hualin.flymsg.activity.ChatActivity;
import online.hualin.flymsg.data.User;
import online.hualin.flymsg.db.ChatHistory;

public class ChatHisAdapter extends RecyclerView.Adapter<ChatHisAdapter.ViewHolder> {
    protected Resources res;
    List<ChatHistory> chatHisList;
    private Context mContext;

    public ChatHisAdapter( List<ChatHistory> chatHisList) {
        this. chatHisList = chatHisList;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (mContext == null) {
            mContext = parent.getContext();
        }
        View view = LayoutInflater.from(mContext).inflate(R.layout.history_card, parent, false);
        final ViewHolder holder = new ViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ChatHistory chatHis=chatHisList.get(position);
        holder.sendIp.setText(chatHis.getSenderIp());
        holder.sendName.setText(chatHis.getSenderName());
        holder.sendMsg.setText(chatHis.getSendMsg());
    }

    @Override
    public int getItemCount() {
        return chatHisList.size();
    }


    static class ViewHolder extends RecyclerView.ViewHolder {
        CardView cardView;
        TextView sendIp;
        TextView sendName;
        TextView sendMsg;


        public ViewHolder(View view) {
            super(view);
            cardView = (CardView) view;
            sendIp=view.findViewById(R.id.sender_ip);
            sendName=view.findViewById(R.id.sender_name);
            sendMsg=view.findViewById(R.id.send_msg);
        }
    }

}
