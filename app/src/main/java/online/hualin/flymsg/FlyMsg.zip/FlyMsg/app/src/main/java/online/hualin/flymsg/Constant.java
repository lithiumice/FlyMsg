package online.hualin.flymsg;


public class Constant {

    public static String APP_URL = "https://play.google.com/store/apps/details?id=TODO";
    public static String EMAIL = "mailto:geakcr@gmail.com";
    public static String GIT_HUB = "https://github.com/lithiumice";
    public static String MY_WEBSITE = "https://hualin.online";
    private static String DESIGNED_BY = "Designed by lithiumice";
    public static String SHARE_CONTENT = "A File and Chat software:\n" + APP_URL + "\n- " + DESIGNED_BY;

}
