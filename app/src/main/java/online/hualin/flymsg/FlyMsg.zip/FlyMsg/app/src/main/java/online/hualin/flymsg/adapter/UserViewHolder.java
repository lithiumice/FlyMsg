package online.hualin.flymsg.adapter;

public class UserViewHolder {
}
