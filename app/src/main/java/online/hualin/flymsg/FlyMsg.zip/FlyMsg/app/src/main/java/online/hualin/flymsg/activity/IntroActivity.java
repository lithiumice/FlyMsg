package online.hualin.flymsg.activity;

import androidx.annotation.ColorInt;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.Manifest;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import online.hualin.flymsg.R;

public class IntroActivity {}